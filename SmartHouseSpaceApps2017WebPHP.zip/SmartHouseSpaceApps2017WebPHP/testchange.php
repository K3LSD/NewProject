<!DOCTYPE html>
<html>
<head>
	<title>Test...</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
	<script type="text/javascript">
		function updateTextInput(val) {
          document.getElementById('textInput').innerHTML = val;
          $("#result").text("");
          $.ajax ({
					url: "change.php",
					type: "POST",
					data: ({changeTemp: val}),
					dataType: "HTML",
					success: funcSuccess
				});
          function funcSuccess(data) {
			var array = JSON.parse(data);
			
			$("#result").text(array[0]);
			}
        }
        function switchUpd() 
        {
          var val = $("#switch").attr("value");
         $("#swicthResult").text("Load...");
          $.ajax ({
					url: "change.php",
					type: "POST",
					data: ({changeSwitch: val}),
					dataType: "HTML",
					success: funcSuccess
				});
          function funcSuccess(data) 
          {
				var array = JSON.parse(data);
         		
				$("#switchResult").text("");
				$("#switchResult").text(array[0]);

				if(array[1] == 0)
				{
					$("#switch").attr("value", "1");
					$("#switch").text("Off");
				}
				else
				{
					$("#switch").attr("value", "0");
					$("#switch").text("On");
				}	
			}
        }

	</script>
	<link rel="stylesheet" type="text/css" href="switch.css">
</head>
<body>
<p>Change Tempreture</p>
<form>
	<input type="range" name="setTemp" min="0" max="30"  onchange="updateTextInput(this.value);">
	<p id="textInput"></p>
	<p id="result"></p>
</form>
<br>
	<p>Change switch</p>
	  <button onclick="switchUpd();" id="switch" value="1">On</button>
	  <!-- <input type="hidden" name="switchVal" value=""> -->
	<p id="switchResult"></p>

<script type="text/javascript">
	document.getElementById('textInput').innerHTML =15;

</script>
</body>
</html>
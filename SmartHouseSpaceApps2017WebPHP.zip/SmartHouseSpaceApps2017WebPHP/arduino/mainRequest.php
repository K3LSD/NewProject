<?php 
include '../conn.php';

	echo "<data>";
if (isset($_POST['usid'])) {
	$usid = $_POST['usid'];
	if (isset($_POST['temperatureControl'])) {
		if(isset($_POST['temperaturenow']))
		{
			$temp = $_POST['temperaturenow'];
			$sql = "SELECT `temperatureNow` FROM `temperatureControl` WHERE `userid` = '" . $usid ."'";
			$res = mysqli_query($conn, $sql);
			$result = mysqli_fetch_assoc($res);
			if($result['temperatureNow'] == $temp)
			{

			}
			else
			{
				$sql = "UPDATE `temperatureControl` SET `temperatureNow` = '$temp' WHERE `userid` = '" . $usid ."'";
				$res = mysqli_query($conn, $sql);
			}
		}
		
		$sql = "SELECT * FROM `temperatureControl` WHERE `userid` = '" . $usid ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		$t =  $result['temperatureSet'] ;
		
		if($result['temperatureSetHasChanged'] == 1)
		{
			$sql = "UPDATE `temperatureControl` SET `temperatureSetHasChanged` = '0' WHERE `userid` = '" . $usid ."'";
			$res = mysqli_query($conn, $sql);
		}
		echo "<tmpSet>" .$t . "</tmpSet>";

		if(isset($_POST['heatingstate']))
		{
			$heat = $_POST['heatingstate'];
			$sql = "SELECT `heatingState` FROM `temperatureControl` WHERE `userid` = '" . $usid ."'";
			$res = mysqli_query($conn, $sql);
			$result = mysqli_fetch_assoc($res);	
			if($heat != $result['heatingState']) {
				$sql = "UPDATE `temperatureControl` SET `heatingState` = '$heat' WHERE `userid` = '" . $usid ."'";
				$res = mysqli_query($conn, $sql);
			}
		}
		
		if(isset($_POST['coolingstate']))
		{
			$heat = $_POST['coolingstate'];
			$sql = "SELECT `coolingState` FROM `temperatureControl` WHERE `userid` = '" . $usid ."'";
			$res = mysqli_query($conn, $sql);
			$result = mysqli_fetch_assoc($res);	
			if($heat != $result['coolingState']) {
				$sql = "UPDATE `temperatureControl` SET `coolingState` = '$heat' WHERE `userid` = '" . $usid ."'";
				$res = mysqli_query($conn, $sql);
			}
		}
	}
	
	if(isset($_POST['swtch'])) {
		$state = $_POST['swtch'];
		$sql = "SELECT * FROM `switchControl` WHERE `userid` = '" .  $usid  ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		if($result['hasChanged'] == "1") {
			$sql = "UPDATE `switchControl` SET `hasChanged` = '0' WHERE `userid` = '" . $usid ."'";
		}
		echo "<swSt>" . $result['state'] . "</swSt>";
	}
	if(isset($_POST['motion']))
	{
		$sql = "UPDATE `motionSensor` SET `movedSomethingWeb` = '1', `movedSomethingMobile` = '1'  WHERE `userid` = '$usid'";
		$res = mysqli_query($conn, $sql);

	}
	echo "</data>";
} else {
	echo "<err>1</err>";
}
?>
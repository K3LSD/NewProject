<?php 
include '../conn.php';
	if(isset($_POST['tempreturenow']))
	{
		$temp = $_POST['tempreturenow'];
		$sql = "SELECT `tempretureNow` FROM `temrpetureControl` WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		if($result['tempretureNow'] == $temp)
		{

		}
		else
		{
			$sql = "UPDATE `temrpetureControl` SET `tempretureNow` = '$temp' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
			$res = mysqli_query($conn, $sql);
		}
	}
	if(isset($_POST['haschanged']))
	{
		$sql = "SELECT * FROM `temrpetureControl` WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		if($result['temperatureSetHasChanged'] == 1)
		{
			echo $result['temperatureSet'];
			$sql = "UPDATE `temrpetureControl` SET `temperatureSetHasChanged` = '0' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
			$res = mysqli_query($conn, $sql);
		}
		else
		{
			
		}
	}
	if(isset($_POST['heatingstate']))
	{
		$heat = $_POST['heatingstate'];
		$sql = "SELECT `heatingState` FROM `temrpetureControl` WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);	
		if($heat == $result['heatingState'])
		{

		}
		else
		{
			$sql = "UPDATE `temrpetureControl` SET `heatingState` = '$heat' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
			$res = mysqli_query($conn, $sql);
		}
	}
	if(isset($_POST['coolingstate']))
	{
		$heat = $_POST['coolingstate'];
		$sql = "SELECT `coolingState` FROM `temrpetureControl` WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);	
		if($heat == $result['coolingState'])
		{

		}
		else
		{
			$sql = "UPDATE `temrpetureControl` SET `coolingState` = '$heat' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
			$res = mysqli_query($conn, $sql);
		}
	}

?>
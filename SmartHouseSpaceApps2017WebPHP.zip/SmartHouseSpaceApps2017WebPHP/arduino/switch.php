<?php 
include '../conn.php';

if(isset($_POST['state'])) // Getting state of Arduino and changing in DB
{
	$state = $_POST['state'];
		$sql = "SELECT `state` FROM `switchControl` WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		if($result['state'] == $state)
		{

		}
		else
		{
			$sql = "UPDATE `switchControl` SET `state` = '$state' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
			$res = mysqli_query($conn, $sql);
		}
}
if(isset($_POST['changestate'])) // Getting new state from Web and changing in DB
{
	
		$sql = "SELECT `state` FROM `switchControl` WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		if($result['state'] == $state)
		{

		}
		else
		{
			$sql = "UPDATE `switchControl` SET `state` = '$state', `hasChanged` = '1' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
			$res = mysqli_query($conn, $sql);
		}
}
if(isset($_POST['haschanged'])) // CHecking if state has changed, changing in Arduino
{
	$sql = "SELECT * FROM `switchControl` WHERE `userid` = '" .  $_SESSION['user']['id']  ."'";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);
	if($result['hasChanged'] == $_POST['haschanged'])
	{

	}
	else
	{
		echo $result['state'];
		$sql = "UPDATE `switchControl` SET `hasChanged` = '0' WHERE `userid` = '" . $_SESSION['user']['id'] ."'";
		$res = mysqli_query($conn, $sql);
	}
}
?>
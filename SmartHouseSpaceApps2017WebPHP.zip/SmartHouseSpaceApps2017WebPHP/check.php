	<?php 
include 'conn.php';

$data = array();

if(isset($_POST['checktemp']) && $_POST['checktemp'] == true)
{
	$sql = "SELECT * FROM `temperatureControl`"; //--------ADD WHERE userid = '". $_SESSION['user']['id'] ."'"
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);
	if(isset($_POST['android']))
	{
		$and_array = array('tempnow' => $result['temperatureNow'], 
							'heatingState' => $result['heatingState'],
							'coolingState' => $result['coolingState'],
							'tempset' => $result['temperatureSet'],
							);
		$and  = json_encode($and_array);
		echo '{"sys": ' . $and . '}	';
	}
	array_push($data, $result['temperatureNow']);
	array_push($data, $result['heatingState']);
	array_push($data, $result['coolingState']);
}
if(isset($_POST['checkswitch']) && $_POST['checkswitch'] == true)
{
	$sql = "SELECT `state` FROM `switchControl`"; //--------ADD WHERE userid = '". $_SESSION['user']['id'] ."'"
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);
	if($result['state'] == 1)
	{
		$state = "On";
	}
	else if($result['state'] == 0)
	{
		$state = "Off";
	}	
	array_push($data, $state);
}

$data_encoded = json_encode($data);
echo $data_encoded;

?>
<?php 

include 'conn.php';
$data = array();
if(isset($_POST['getSwitchValue']))
{
	$sql = "SELECT * FROM `switchControl`";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);

	if($result['state'] == 0)
	{
		echo 0;
	}
	else if($result['state'] == 1)
	{
		echo  1;
	}
}
if(isset($_POST['changeTemp']))
{
	$sql = "SELECT * FROM `temperatureControl`";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);

	if($result['temperatureNow'] == $_POST['changeTemp'])
	{
		array_push($data, "Temperature not changed");
	}
	else
	{
		$newTemp = $_POST['changeTemp'];
		$sql = "UPDATE `temperatureControl` SET `temperatureSet` = '$newTemp', `temperatureSetHasChanged` = 1";
		$res = mysqli_query($conn, $sql);
		array_push($data, "New Temperature setted!");
	}
}

if(isset($_POST['changeSwitch']))
{
	$sql = "SELECT * FROM `switchControl`";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);

	if($result['state'] == $_POST['changeSwitch'])
	{
		array_push($data, "Switch not changed");
	}
	else
	{
		$new = $_POST['changeSwitch'];
		$sql = "UPDATE `switchControl` SET `state` = '$new', `hasChanged` = 1";
		$res = mysqli_query($conn, $sql);
		array_push($data, "Switch has changed");
		array_push($data, $_POST['changeSwitch']);
	}
}

$data_encoded = json_encode($data);
echo $data_encoded;
?>
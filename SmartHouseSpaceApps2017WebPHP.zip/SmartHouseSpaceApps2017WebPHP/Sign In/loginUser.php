<?php 
include '../conn.php';
if(isset($_POST['loginUser']))
{
	if(isset($_POST['username']) && isset($_POST['password']))
	{
		$usr = $_POST['username'];
		$pass = $_POST['password'];

		$sql = "SELECT * FROM `userGeneral` WHERE `username` = '$usr' AND `password` = '$pass'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);

		if(isset($result['userid']))
		{
			$_SESSION['user']['login'] = true;
			$_SESSION['user']['id'] = $result['userid'];
			$_SESSION['user']['username'] = $result['username'];
			$_SESSION['user']['password'] = $result['password'];
			header("Location: http://smart-house.ga");
		}
		else
		{
			header("Location: /Sign In");
		}
	}
	else
	{
		header("Location: /Sign In");
	}
}
?>
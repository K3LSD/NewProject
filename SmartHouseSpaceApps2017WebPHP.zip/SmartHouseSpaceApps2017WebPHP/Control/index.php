<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Smart House</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="author" content="http://bootstraptaste.com" />
<!-- css -->
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/
style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script type="text/javascript"> 
  var check = setInterval(function()
  {
    // Which modules check
    var checktemp = true;
    var checkswitch = true;
    $.ajax ({
          url: "/checkMotion.php",
          type: "POST",
          data: ({motion: "Web"}),
          dataType: "HTML",
          success: funcSuccessMotion
        });
    function funcSuccessMotion(data)
    {
      if(data == 1)
      {
        alert("Warning!!! Motion has been noticed");
        console.log(data);    
      }
    }
    $.ajax ({
          url: "../check.php",
          type: "POST",
          data: ({checktemp: checktemp, checkswitch: checkswitch}),
          dataType: "HTML",
          success: funcSuccessTemp
        });
  }, 1000);

  function funcSuccessTemp(data) {
      var array = JSON.parse(data);
      var temp  = [array[0], array[1], array[2]];
      var switchM = array[3];

      if(temp[1] == 0)
      {
        temp[1] = "Off";
      }
      else if(temp[1] == 1)
      {
        temp[1] = "On";
      }
      if(temp[2] == 0)
      {
        temp[2] = "Off";
      }
      else if(temp[2] == 1)
      {
        temp[2] = "On";
      }
      for (var i = 0; i < temp.length; i++) 
      {
        $("#temp" + i).text(temp[i]);
      }
      $("#switchM").text(switchM);
    }
  </script>
  <script type="text/javascript">
    function updateTextInput(val) {
          document.getElementById('textInput').innerHTML = val;
          $("#result").text("");
          $.ajax ({
          url: "../change.php",
          type: "POST",
          data: ({changeTemp: val}),
          dataType: "HTML",
          success: funcSuccess
        });
          function funcSuccess(data) {
      var array = JSON.parse(data);
      
      $("#result").text(array[0]);
      }
        }
        function switchUpd() 
        {
          var val = $("#switch").attr("value");
         $("#swicthResult").text("Load...");
          $.ajax ({
          url: "../change.php",
          type: "POST",
          data: ({changeSwitch: val}),
          dataType: "HTML",
          success: funcSuccess
        });
          function funcSuccess(data) 
          {
        var array = JSON.parse(data);
            
        $("#switchResult").text("");
        $("#switchResult").text(array[0]);

        if(array[1] == 0)
        {
          $("#switch").attr("value", "1");
          $("#switch").text("On");
          $("#switch").css({"background-color": "#4CAF50"});
        }
        else
        {
          $("#switch").attr("value", "0");
          $("#switch").text("Off");
          $("#switch").css({"background-color": "#c30d0d"});
        } 
      }
        }

  </script>
</head>
<body>
<style>
body {
	margin:0;
	background-color: #01A4E1;
	overflow-y: hidden;
}

.topnav {
  overflow: hidden;
  background-color: #2A2A2A;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #606468;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }

}
.radius1{
	height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 7px;
}
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
#slider {
  width: 400px;
  height: 17px;
  position: relative;
  margin: 100px auto;
  background: #10171D;
  -webkit-border-radius: 40px;
  -moz-border-radius: 40px;
  border-radius: 40px;
  -webkit-box-shadow: inset 0px 0px 1px 1px rgba(0, 0, 0, 0.9), 0px 1px 1px 0px rgba(255, 255, 255, 0.13);
  -moz-box-shadow: inset 0px 0px 1px 1px rgba(0, 0, 0, 0.9), 0px 1px 1px 0px rgba(255, 255, 255, 0.13);
  box-shadow: inset 0px 0px 1px 1px rgba(0, 0, 0, 0.9), 0px 1px 1px 0px rgba(255, 255, 255, 0.13);
}
#slider .bar {
  width: 388px;
  height: 5px;
  background: #333;
  position: relative;
  top: -4px;
  left: 4px;
  background: #1d2e38;
  background: -moz-linear-gradient(left, #1d2e38 0%, #2b4254 50%, #2b4254 100%);
  background: -webkit-gradient(linear, left top, right top, color-stop(0%, #1d2e38), color-stop(50%, #2b4254), color-stop(100%, #2b4254));
  background: -webkit-linear-gradient(left, #1d2e38 0%, #2b4254 50%, #2b4254 100%);
  background: -o-linear-gradient(left, #1d2e38 0%, #2b4254 50%, #2b4254 100%);
  background: -ms-linear-gradient(left, #1d2e38 0%, #2b4254 50%, #2b4254 100%);
  background: linear-gradient(left, #1d2e38 0%, #2b4254 50%, #2b4254 100%);
  filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#1d2e38', endColorstr='#2b4254', GradientType=1);
  -webkit-border-radius: 40px;
  -moz-border-radius: 40px;
  border-radius: 40px;
}
#slider .highlight {
  height: 2px;
  position: absolute;
  width: 388px;
  top: 6px;
  left: 6px;
  -webkit-border-radius: 40px;
  -moz-border-radius: 40px;
  border-radius: 40px;
  background: rgba(255, 255, 255, 0.25);
}
input[type="range"] {
  -webkit-appearance: none;
  background-color: black;
  height: 2px;
}
input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  position: relative;
  top: 0px;
  z-index: 1;
  width: 11px;
  height: 11px;
  cursor: pointer;
  -webkit-box-shadow: 0px 6px 5px 0px rgba(0, 0, 0, 0.6);
  -moz-box-shadow: 0px 6px 5px 0px rgba(0, 0, 0, 0.6);
  box-shadow: 0px 6px 5px 0px rgba(0, 0, 0, 0.6);
  -webkit-border-radius: 40px;
  -moz-border-radius: 40px;
  border-radius: 40px;
  background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #ebf1f6), color-stop(50%, #abd3ee), color-stop(51%, #89c3eb), color-stop(100%, #d5ebfb));
}
input[type="range"]:hover ~ #rangevalue,
input[type="range"]:active ~ #rangevalue {
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
  filter: alpha(opacity=100);
  opacity: 1;
  top: -75px;
}
/* Tool Tip */

#rangevalue {
  color: white;
  font-size: 10px;
  text-align: center;
  font-family: Arial, sans-serif;
  display: block;
  color: #fff;
  margin: 20px 0;
  position: relative;
  left: 44.5%;
  padding: 6px 12px;
  border: 1px solid black;
  -webkit-box-shadow: inset 0px 1px 1px 0px rgba(255, 255, 255, 0.2), 0px 2px 4px 0px rgba(0, 0, 0, 0.4);
  -moz-box-shadow: inset 0px 1px 1px 0px rgba(255, 255, 255, 0.2), 0px 2px 4px 0px rgba(0, 0, 0, 0.4);
  box-shadow: inset 0px 1px 1px 0px rgba(255, 255, 255, 0.2), 0px 2px 4px 0px rgba(0, 0, 0, 0.4);
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #222931), color-stop(100%, #181D21));
  -webkit-border-radius: 20px;
  -moz-border-radius: 20px;
  border-radius: 20px;
  width: 18px;
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
  filter: alpha(opacity=0);
  opacity: 0;
  -webkit-transition: all 0.5s ease;
  -moz-transition: all 0.5s ease;
  -o-transition: all 0.5s ease;
  -ms-transition: all 0.5s ease;
  transition: all 0.5s ease;
  top: -95px;
}
input[type="range"]:focus {
  outline: none;
}
#switch{
  background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
</style>
</head>
<body>
<div class="topnav" id="myTopnav">
  <a href="../"><b>Home</b></a>
  <a href="../Control"><b>Control</b></a>
  <a href="../Contact"><b>Contact</b></a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
<center>
<hr>
<div class="container">
  
<div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/temperature.png"></a></center></div>
 <div class="modal fade" id="myModal" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Temperature</h4>
        </div>
        <div class="modal-body">
          <p>Tempreture Now: <span id="temp0"></span><sup>°</sup>C</p>
          <p>Heating State: <span id="temp1"></span></p>
          <p>Cooling State: <span id="temp2"></span></p>
          <input type="range" name="setTemp" min="0" max="30"  onchange="updateTextInput(this.value);">
          <p id="textInput"></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>

 <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/air conditioning indoor.png"></a></center></div>
 <div class="modal fade" id="myModal1" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Air condition</h4>
        </div>
        <div class="modal-body">
          <p>Off/On  </p><label class="switch">
  <input type="checkbox">
  <div class="slider round"></div>
</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div><div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/bulb.png"></a></center></div>
 <div class="modal fade" id="myModal2" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">All bulbs</h4>
        </div>
        <div class="modal-body">
          <p>Off/On  </p><label class="switch">
  <button onclick="switchUpd();" id="switch" value="1">On</button>
</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div><div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 7px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal3" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/alarm.png"></a></center></div>
 <div class="modal fade" id="myModal3" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Alarm</h4>
        </div>
        <div class="modal-body">
          <p>Off/On</p><label class="switch">
  <input type="checkbox">
  <div class="slider round"></div>
</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal4" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/plug.png"></a></center></div>
 <div class="modal fade" id="myModal4" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Plugs</h4>
        </div>
        <div class="modal-body">
          <p>Off/On  </p><label class="switch">
  <input type="checkbox">
  <div class="slider round"></div>
</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal5" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/remote control.png"></a></center></div>
 <div class="modal fade" id="myModal5" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>`
   <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal6" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/key.png"></a></center></div>
 <div class="modal fade" id="myModal6" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   <br>







<div class="container">
  
<div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal17" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/dome camera.png"></a></center></div>
 <div class="modal fade" id="myModal17" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">IP camera</h4>
        </div>
        <div style="height: 300px" class="modal-body">
          <iframe style="overflow-y:hidden; " height="100%" width="65%" src="http://192.168.8.137:8080/flash.html" ></iframe>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>

 <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal8" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/weather.png"></a></center></div>
 <div class="modal fade" id="myModal9" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Weather</h4>
        </div>
        <div class="modal-body">
          <p>Current weather - </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div><div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal10" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/lock a.png"></a></center></div>
 <div class="modal fade" id="myModal10" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Lock case</h4>
        </div>
        <div class="modal-body">
          <p>Unlock/Lock</p><label class="switch">
  <input type="checkbox">
  <div class="slider round"></div>
</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div><div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 7px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal11" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/doorbell.png"></a></center></div>
 <div class="modal fade" id="myModal11" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Door bell</h4>
        </div>
        <div class="modal-body">
          <p>Disable/Enable</p><label class="switch">
  <input type="checkbox">
  <div class="slider round"></div>
</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal12" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/solar panel.png"></a></center></div>
 <div class="modal fade" id="myModal12" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Solar panel</h4>
        </div>
        <div class="modal-body">
          <p>Saved energy - </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal13" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/tv.png"></a></center></div>
 <div class="modal fade" id="myModal13" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">TV</h4>
        </div>
        <div class="modal-body">
          <p>Off/On  </p><label class="switch">
  <input type="checkbox">
  <div class="slider round"></div>
</label>        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   <div style="padding-top: 16px;display: inline-block;">
 <div  style="height: 150px;
	width: 150px;
	background-color: grey;
	border-radius: 100%;
	display: inline-block;
	margin: 2px;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal16" class="radius1"><center><a href="#"><img style="margin-top: 17%; width: 90px;" src="../img/icons/thermostat.png"></a></center></div>
 <div class="modal fade" id="myModal16" role="dialog">
 <!-- Modal content-->
      <div style="width: 70%;height:auto;margin-top: 20%" class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
   </div>
   </div>
   </div>
   </div>
</hr>
</div>
<hr>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<!-- <script src="../js/jquery.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.fancybox.pack.js"></script>
<script src="../js/jquery.fancybox-media.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/portfolio/jquery.quicksand.js"></script>
<script src="../js/portfolio/setting.js"></script>
<script src="../js/jquery.flexslider.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script> -->
<script type="text/javascript">
  document.getElementById('textInput').innerHTML =15;

</script>

</body>
</html>
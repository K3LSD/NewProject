
<?php
include 'conn.php'; 

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; //!*()-_=+/`~?<>\|';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function checkInDB($str) {
	global $conn;
	$sql = "SELECT * FROM `userCookies` WHERE `cookie` = '" . $str . "'";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);
	if($result)
	{
		return 1;
	}
	else
	{
		return 0;
	}
} 

function putInCookie($str, $usrId) 
{
	global $conn;
	$sql = "INSERT INTO `userCookies`(`userid`, `cookie`) VALUES ('$usrId','$str')";
	$res = mysqli_query($conn, $sql);
}


function generateRandomStringWithoutInDataBase($length = 10, $usrId) {
	$state = false;
	$st = generateRandomString($length);
	while ($state == false) {
		if (checkInDB($st) == 0) {
			$state = true;
		}
		$st = generateRandomString(64);
		putInCookie($st, $usrId);
	}
	return $st;
}


$jsonObj->mnRes = "0";
$jsonObj->tok = "no";


//echo checkInDB("valsdionfdbaincmo");
// echo $conn;
if (isset($_POST['username']) && isset($_POST['password'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM `userGeneral` WHERE `username` = '$username' AND `password` = '$password'";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);

	if(isset($result['userid']))
	{
		//$_SESSION['admin']['logedin'] = true;
		//$_SESSION['admin']['id'] = $result['adminId'];
		
		//header("Location: /admin");
		$jsonObj->mnRes = "1";
		$jsonObj->tok = $result['userid'];
		//echo "valods";
	} else {
		//
	}
}
else {
	//header("Location: /admin/login/");
	$jsonObj->tok = "err";
}


$myJSON = json_encode($jsonObj);

echo '{"sys":' .$myJSON . '}';

?>

<!DOCTYPE html>
<html>
<head>
	<title>Test...</title>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
	<script type="text/javascript">
	var check = setInterval(function()
	{
		// Which modules check
		var checktemp = true;
		var checkswitch = true;

		$.ajax ({
					url: "check.php",
					type: "POST",
					data: ({checktemp: checktemp, checkswitch: checkswitch}),
					dataType: "HTML",
					success: funcSuccess
				});
	}, 1000);

	function funcSuccess(data) {
			var array = JSON.parse(data);
			var temp  = [array[0], array[1], array[2]];
			var switchM = array[3];

			for (var i = 0; i < temp.length; i++) 
			{
				$("#temp" + i).text(temp[i]);
			}
			$("#switchM").text(switchM);
		}
	</script>
</head>
<body>
<p>Tempreture: <span id="temp0"></span><br>
	Heating State: <span id="temp1"></span><br>
	Cooling State: <span id="temp2"></span><br>
	Switch: <span id="switchM"></span></p>
</body>
</html>
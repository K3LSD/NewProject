<?php 
include 'conn.php';
$usrid = "";
if(isset($_POST['motion']))
{
	if(isset($_POST['usrid']))
	{
		$usrid = $_POST['usrid']; 
	}
	else if(isset($_SESSION['user']['login']) && $_SESSION['user']['login'] == true)
	{
		$usrid = $_SESSION['user']['id'];	
	}
	if($_POST['motion'] == "Web" || $_POST['motion'] == "Mobile")
	{
		$mot = 'movedSomething' . $_POST['motion'];
		$sql = "SELECT * FROM `motionSensor` WHERE `userid` = '$usrid'";
		$res = mysqli_query($conn, $sql);
		$result = mysqli_fetch_assoc($res);
		if($result[$mot] == 0)
		{
			echo 0;
		}
		else if($result[$mot] == 1)
		{
			if($mot == "movedSomethingMobile")
			{
				$sql = "UPDATE `motionSensor` SET `movedSomethingMobile` = '0' WHERE `userid` = '$usrid'";
			}
			if($mot == "movedSomethingWeb")
			{
				$sql = "UPDATE `motionSensor` SET `movedSomethingWeb` = '0' WHERE `userid` = '$usrid'";
			}
			$res = mysqli_query($conn, $sql);
			echo 1;
		}
	}
}

?>
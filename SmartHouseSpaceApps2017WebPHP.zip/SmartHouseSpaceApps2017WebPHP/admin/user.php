<?php 
include '../conn.php';

if(isset($_POST['adduser']))
{
	$firstname = $_POST['firstname'];
	$secondname = $_POST['secondname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$country = $_POST['country'];
	$id = RandomString();

	$sql = "INSERT INTO `userGeneral`(`userid`, `firstname`, `secondname`, `username`, `email`, `password`, `phonenumber`, `address`, `country`) VALUES ('$id','$firstname','$secondname','$username','$email','$password','$phonenumber','$address','$country')";
	$res = mysqli_query($conn, $sql);

	header("Location: /admin");
}
else if(isset($_POST['edituser']))
{
	$firstname = $_POST['firstname'];
	$secondname = $_POST['secondname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$country = $_POST['country'];
	$id = $_POST['userid'];

	$sql = "UPDATE `userGeneral` SET `firstname`='$firstname',`secondname`='$secondname',`username`='$username',`email`='$email',`phonenumber`='$phonenumber',`address`='$address',`country`='$country' WHERE userid = '$id'";
	$res = mysqli_query($conn, $sql);

	header("Location: /admin");
}
?>
<?php 
include '../../conn.php';


if (isset($_SESSION['admin']) && $_SESSION['admin']['logedin'] === true)
{
	?> 


<!DOCTYPE html>
<html>
<head>
	<title>Add user</title>
	<style type="text/css">
	table, td{
		border: 1px solid black;
		border-collapse: collapse;
	}
	</style>
</head>
<body>
<table>
	<tr>
		<th>ID</th>
		<th>First Name</th>
		<th>Second Name</th>
		<th>Username</th>
		<th>E-Mail</th>
		<th>Phone Number</th>
		<th>Address</th>
		<th>Country</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php 
	$sql = "SELECT * FROM `userGeneral`";
	$res = mysqli_query($conn, $sql);
		while($row = mysqli_fetch_assoc($res))
		{
			?>
			<tr>
				<td><?php echo $row['userid'] ?></td>
				<td><?php echo $row['firstname'] ?></td>
				<td><?php echo $row['secondname'] ?></td>
				<td><?php echo $row['username'] ?></td>
				<td><?php echo $row['email'] ?></td>
				<td><?php echo $row['phonenumber'] ?></td>
				<td><?php echo $row['address'] ?></td>
				<td><?php echo $row['country'] ?></td>
				<td><a href="edit.php?id=<?php echo $row['userid'] ?>">Edit</a></td>
				<td><a href="delete.php?id=<?php echo $row['userid'] ?>">Delete</a></td>
			</tr>
			<?php
		}
	?>
</table>
</body>
</html>

<?php
}
else
{
	header("Location: /admin/login");
}
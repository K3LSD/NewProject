<?php 
include '../../conn.php';


if (isset($_SESSION['admin']) && $_SESSION['admin']['logedin'] === true && isset($_GET['id']))
{
	$sql = "SELECT * FROM `userGeneral` WHERE userid = '" . $_GET['id'] ."'";
	$res = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($res);
	?> 


<!DOCTYPE html>
<html>
<head>
	<title>Add user</title>
</head>
<body>
<form action="../user.php" method="POST">
	<input type="hidden" name="userid" value="<?php echo $_GET['id'] ?>">
	<label>First Name: </label><input type="text" name="firstname" placeholder="First Name" value="<?php echo $row['firstname'] ?>"><br>
	<label>Second Name: </label><input type="text" name="secondname" placeholder="Second Name" value="<?php echo $row['secondname'] ?>"><br>
	<label>Username: </label><input type="text" name="username" placeholder="Username" value="<?php echo $row['username'] ?>"><br>
	<label>E-Mail: </label><input type="email" name="email" placeholder="E-Mail" value="<?php echo $row['email'] ?>"><br>
	<label>Phonenumber: </label><input type="text" name="phonenumber" placeholder="Phone Number" value="<?php echo $row['phonenumber'] ?>"><br>
	<label>Address: </label><input type="text" name="address" placeholder="Address" value="<?php echo $row['address'] ?>"><br>
	<label>Country: </label><input type="text" name="country" placeholder="Country" value="<?php echo $row['country'] ?>"><br>
	<input type="submit" name="edituser" value="Edit">


</form>
</body>
</html>

<?php
}
else
{
	header("Location: /admin/login");
}
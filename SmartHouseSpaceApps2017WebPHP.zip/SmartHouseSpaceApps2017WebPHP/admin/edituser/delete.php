<?php 
include '../../conn.php';
if(isset($_GET['id']))
{
	$id = $_GET['id'];
	$sql = "DELETE FROM `userGeneral` WHERE userid = '$id'";
	$res = mysqli_query($conn, $sql);

	header("Location: /admin/edituser");
}

?>
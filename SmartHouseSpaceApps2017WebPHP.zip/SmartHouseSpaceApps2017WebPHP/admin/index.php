<?php 
include '../conn.php';

if (isset($_SESSION['admin']) && $_SESSION['admin']['logedin'] === true)
{
	?> 
	<a href="logout.php">Log out</a>
	<br>
	<a href="adduser/">Add new user</a><br>
	<a href="edituser/">Edit user</a><br>
	<?php
}
else
{
	header("Location: login/");
}

?>
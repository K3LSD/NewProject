<?php 
include '../conn.php';

if (isset($_SESSION['admin']) && $_SESSION['admin']['logedin'] === true) {
	header("Location: /admin");
} else {
	include 'login.php';	
}
?>
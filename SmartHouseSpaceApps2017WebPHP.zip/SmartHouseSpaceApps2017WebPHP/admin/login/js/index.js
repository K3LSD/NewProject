$('.login-input').on('focus', function() {
  $('.login').addClass('focused');
});

$('.login').on('submit', function(e) {
	e.preventDefault();
	$('.login').removeClass('focused').addClass('loading');
	var usernameValue = $('#usernameInput').val();
	var passwordValue = $('#passwordInput').val();
  
	$.post("checkLogin.php",
	{
	  username: usernameValue,
	  password: passwordValue
	},
	
	function(data,status){
		//alert("Data: " + data + "\nStatus: " + status);
		if (data.indexOf("1") >= 0) {
			window.location = "/admin";
		} else {
			$(".login").effect( "shake" );
		}
		$('.login').removeClass('loading');
	});
  
});

<?php

include '../../conn.php'; 
// echo $conn;
if (isset($_POST['username']) && isset($_POST['password'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM `admins` WHERE `username` = '$username' AND `password` = '$password'";
	$res = mysqli_query($conn, $sql);
	$result = mysqli_fetch_assoc($res);

	if(isset($result['adminId']))
	{
		$_SESSION['admin']['logedin'] = true;
		$_SESSION['admin']['id'] = $result['adminId'];
		
		//header("Location: /admin");
		echo "1";
	} else {
		echo "0";
	}
}
else
{
	//header("Location: /admin/login/");
	echo "0";
}
?>

<?php 
include '../../conn.php';


if (isset($_SESSION['admin']) && $_SESSION['admin']['logedin'] === true)
{
	?> 


<!DOCTYPE html>
<html>
<head>
	<title>Add user</title>
</head>
<body>
<form action="../user.php" method="POST">
	<input type="text" name="firstname" placeholder="First Name"><br>
	<input type="text" name="secondname" placeholder="Second Name"><br>
	<input type="text" name="username" placeholder="Username"><br>
	<input type="email" name="email" placeholder="E-Mail"><br>
	<input type="password" name="password" placeholder="Password"><br>
	<input type="text" name="phonenumber" placeholder="Phone Number"><br>
	<input type="text" name="address" placeholder="Address"><br>
	<input type="text" name="country" placeholder="Country"><br>
	<input type="submit" name="adduser">


</form>
</body>
</html>

<?php
}
else
{
	header("Location: /admin/login");
}